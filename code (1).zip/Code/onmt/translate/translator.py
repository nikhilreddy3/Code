#!/usr/bin/env python
""" Translator Class and builder """
from __future__ import print_function
import configargparse
import codecs
import os
import math

import torch

from itertools import count
from onmt.utils.misc import tile

import onmt.model_builder
import onmt.translate.beam
import onmt.inputters as inputters
import onmt.opts as opts
import onmt.decoders.ensemble

# add by wchen
from data_utils import EOKP_TOKEN, KEY_SEPERATOR, P_END, A_END, P_START, A_START

def build_translator(opt, report_score=True, logger=None, out_file=None):
    if out_file is None:
        out_file = codecs.open(opt.output, 'w+', 'utf-8')

    dummy_parser = configargparse.ArgumentParser(description='train.py')
    opts.model_opts(dummy_parser)
    dummy_opt = dummy_parser.parse_known_args([])[0]

    # changed by wchen
    load_test_model = onmt.decoders.ensemble.load_test_model \
        if len(opt.models) > 1 else onmt.model_builder.load_test_model

    fields, model, model_opt = load_test_model(opt, dummy_opt.__dict__)

    scorer = onmt.translate.GNMTGlobalScorer(opt)

    # changed to have HRTanslator options
    if 'hrd' in model_opt.decoder_type:
        translator = HRTranslator(
            model,
            fields,
            opt,
            model_opt,
            out_file=out_file,
            logger=logger
        )
    else:
        translator = SeqTranslator(
            model,
            fields,
            opt,
            model_opt,
            global_scorer=scorer,
            out_file=out_file,
            report_score=report_score,
            logger=logger
        )
    return translator


class Translator(object):
    """
    Uses a model to translate a batch of sentences.


    Args:
       model (:obj:`onmt.modules.NMTModel`):
          NMT model to use for translation
       fields (dict of Fields): data fields
       beam_size (int): size of beam to use
       n_best (int): number of translations produced
       max_length (int): maximum length output to produce
       global_scores (:obj:`GlobalScorer`):
         object to rescore final translations
       copy_attn (bool): use copy attention during translation
       cuda (bool): use cuda
       beam_trace (bool): trace beam search for debugging
       logger(logging.Logger): logger.
    """

    def __init__(
        self,
        model,
        fields,
        opt,
        model_opt,
        global_scorer=None,
        out_file=None,
        report_score=True,
        logger=None
    ):

        self.model = model
        self.fields = fields
        self.gpu = opt.gpu
        self.cuda = opt.gpu > -1

        self.n_best = opt.n_best
        self.max_length = opt.max_length

        if opt.beam_size != 1 and opt.random_sampling_topk != 1:
            raise ValueError('Can either do beam search OR random sampling.')

        self.beam_size = opt.beam_size
        self.random_sampling_temp = opt.random_sampling_temp
        self.sample_from_topk = opt.random_sampling_topk

        self.min_length = opt.min_length
        self.stepwise_penalty = opt.stepwise_penalty
        self.dump_beam = opt.dump_beam
        self.block_ngram_repeat = opt.block_ngram_repeat
        self.ignore_when_blocking = set(opt.ignore_when_blocking)
        self.sample_rate = opt.sample_rate
        self.window_size = opt.window_size
        self.window_stride = opt.window_stride
        self.window = opt.window
        self.image_channel_size = opt.image_channel_size
        self.replace_unk = opt.replace_unk
        self.data_type = opt.data_type
        self.verbose = opt.verbose
        self.report_bleu = opt.report_bleu
        self.report_rouge = opt.report_rouge
        self.fast = opt.fast

        self.copy_attn = model_opt.copy_attn

        self.global_scorer = global_scorer
        self.out_file = out_file
        self.report_score = report_score
        self.logger = logger

        self.use_filter_pred = False

        # add by wchen
        self.forbid_unk = opt.forbid_unk

        # for debugging
        self.beam_trace = self.dump_beam != ""
        self.beam_accum = None
        if self.beam_trace:
            self.beam_accum = {
                "predicted_ids": [],
                "beam_parent_ids": [],
                "scores": [],
                "log_probs": []}

    def translate(
        self,
        src,
        src_title=None,
        tgt=None,
        src_dir=None,
        batch_size=None,
        attn_debug=False
    ):
        """
        Translate content of `src_data_iter` (if not None) or `src_path`
        and get gold scores if one of `tgt_data_iter` or `tgt_path` is set.

        Note: batch_size must not be None
        Note: one of ('src_path', 'src_data_iter') must not be None

        Args:
            src_path (str): filepath of source data
            tgt_path (str): filepath of target data or None
            src_dir (str): source directory path
                (used for Audio and Image datasets)
            batch_size (int): size of examples per mini-batch
            attn_debug (bool): enables the attention logging

        Returns:
            (`list`, `list`)

            * all_scores is a list of `batch_size` lists of `n_best` scores
            * all_predictions is a list of `batch_size` lists
                of `n_best` predictions
        """
        assert src is not None

        if batch_size is None:
            raise ValueError("batch_size must be set")

        data = inputters.build_dataset(
            self.fields,
            self.data_type,
            src=src,
            title=src_title,
            tgt=tgt,
            src_dir=src_dir,
            sample_rate=self.sample_rate,
            window_size=self.window_size,
            window_stride=self.window_stride,
            window=self.window,
            use_filter_pred=self.use_filter_pred,
            image_channel_size=self.image_channel_size,
        )

        cur_device = "cuda" if self.cuda else "cpu"

        data_iter = inputters.OrderedIterator(
            dataset=data,
            device=cur_device,
            batch_size=batch_size,
            train=False,
            sort=False,
            sort_within_batch=True,
            shuffle=False
        )

        builder = onmt.translate.TranslationBuilder(
            data, self.fields, self.n_best, self.replace_unk, tgt
        )

        # Statistics
        counter = count(1)
        pred_score_total, pred_words_total = 0, 0
        gold_score_total, gold_words_total = 0, 0

        all_scores = []
        all_predictions = []

        for batch in data_iter:
            batch_data = self.translate_batch(
                batch, data, attn_debug, fast=self.fast
            )
            translations = builder.from_batch(batch_data)

            for trans in translations:
                all_scores += [trans.pred_scores[:self.n_best]]
                pred_score_total += trans.pred_scores[0]
                pred_words_total += len(trans.pred_sents[0])
                if tgt is not None:
                    gold_score_total += trans.gold_score
                    gold_words_total += len(trans.gold_sent) + 1

                n_best_preds = [" ".join(pred)
                                for pred in trans.pred_sents[:self.n_best]]
                all_predictions += [n_best_preds]
                # self.out_file.write('\n'.join(n_best_preds) + '\n')
                # change by wchen
                self.out_file.write(' {} '.format(KEY_SEPERATOR).join(n_best_preds) + '\n')
                self.out_file.flush()

                if self.verbose:
                    sent_number = next(counter)
                    output = trans.log(sent_number)
                    if self.logger:
                        self.logger.info(output)
                    else:
                        os.write(1, output.encode('utf-8'))

                if attn_debug:
                    preds = trans.pred_sents[0]
                    preds.append('</s>')
                    attns = trans.attns[0].tolist()
                    if self.data_type == 'text':
                        srcs = trans.src_raw
                    else:
                        srcs = [str(item) for item in range(len(attns[0]))]
                    header_format = "{:>10.10} " + "{:>10.7} " * len(srcs)
                    row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    output = header_format.format("", *srcs) + '\n'
                    for word, row in zip(preds, attns):
                        max_index = row.index(max(row))
                        row_format = row_format.replace(
                            "{:>10.7f} ", "{:*>10.7f} ", max_index + 1)
                        row_format = row_format.replace(
                            "{:*>10.7f} ", "{:>10.7f} ", max_index)
                        output += row_format.format(word, *row) + '\n'
                        row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    os.write(1, output.encode('utf-8'))

        if self.report_score:
            msg = self._report_score('PRED', pred_score_total,
                                     pred_words_total)
            if self.logger:
                self.logger.info(msg)
            else:
                print(msg)
            if tgt is not None:
                msg = self._report_score('GOLD', gold_score_total,
                                         gold_words_total)
                if self.logger:
                    self.logger.info(msg)
                else:
                    print(msg)
                if self.report_bleu:
                    msg = self._report_bleu(tgt)
                    if self.logger:
                        self.logger.info(msg)
                    else:
                        print(msg)
                if self.report_rouge:
                    msg = self._report_rouge(tgt)
                    if self.logger:
                        self.logger.info(msg)
                    else:
                        print(msg)

        if self.dump_beam:
            import json
            json.dump(self.translator.beam_accum,
                      codecs.open(self.dump_beam, 'w', 'utf-8'))
        return all_scores, all_predictions

    def sample_with_temperature(self, logits, sampling_temp, keep_topk):
        if sampling_temp == 0.0 or keep_topk == 1:
            # For temp=0.0, take the argmax to avoid divide-by-zero errors.
            # keep_topk=1 is also equivalent to argmax.
            topk_scores, topk_ids = logits.topk(1, dim=-1)
        else:
            logits = torch.div(logits, sampling_temp)

            if keep_topk > 0:
                top_values, top_indices = torch.topk(logits, keep_topk, dim=1)
                kth_best = top_values[:, -1].view([-1, 1])
                kth_best = kth_best.repeat([1, logits.shape[1]])
                kth_best = kth_best.type(torch.cuda.FloatTensor)

                # Set all logits that are not in the top-k to -1000.
                # This puts the probabilities close to 0.
                keep = torch.ge(logits, kth_best).type(torch.cuda.FloatTensor)
                logits = (keep * logits) + ((1-keep) * -10000)

            dist = torch.distributions.Multinomial(
                logits=logits, total_count=1)
            topk_ids = torch.argmax(dist.sample(), dim=1, keepdim=True)
            topk_scores = logits.gather(dim=1, index=topk_ids)
        return topk_ids, topk_scores

    def _translate_random_sampling(
        self,
        batch,
        data,
        max_length,
        min_length=0,
        sampling_temp=1.0,
        keep_topk=-1,
        return_attention=False
    ):
        """Alternative to beam search. Do random sampling at each step."""

        assert self.beam_size == 1

        # TODO: support these blacklisted features.
        assert self.block_ngram_repeat == 0

        batch_size = batch.batch_size

        # vocab = self.fields["tgt"].vocab
        # start_token = vocab.stoi[self.fields["tgt"].init_token]
        # end_token = vocab.stoi[self.fields["tgt"].eos_token]

        # changed by wchen, the above is the original
        tgt_field = self.fields["tgt"][0][1]
        vocab = tgt_field.vocab
        start_token = vocab.stoi[tgt_field.init_token]
        end_token = vocab.stoi[tgt_field.eos_token]
        unk_token = vocab.stoi[tgt_field.unk_token]

        # Encoder forward.
        src, enc_states, memory_bank, src_lengths = self._run_encoder(
            batch, data.data_type)
        self.model.decoder.init_state(src, memory_bank, enc_states)

        use_src_map = data.data_type == 'text' and self.copy_attn

        results = {}
        results["predictions"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["scores"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["attention"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["batch"] = batch

        # # comment by wchen. Do not compute the socres
        # if "tgt" in batch.__dict__:
        #     results["gold_score"] = self._score_target(
        #         batch,
        #         memory_bank,
        #         src_lengths,
        #         data,
        #         batch.src_map if use_src_map else None
        #     )
        #     self.model.decoder.init_state(src, memory_bank, enc_states)
        # else:
        #     results["gold_score"] = [0] * batch_size
        results["gold_score"] = [0] * batch_size

        memory_lengths = src_lengths
        src_map = batch.src_map if use_src_map else None

        if isinstance(memory_bank, tuple):
            mb_device = memory_bank[0].device
        else:
            mb_device = memory_bank.device

        # seq_so_far contains chosen tokens; on each step, dim 1 grows by one.
        seq_so_far = torch.full(
            [batch_size, 1], start_token, dtype=torch.long, device=mb_device)
        alive_attn = None

        for step in range(max_length):
            decoder_input = seq_so_far[:, -1].view(1, -1, 1)

            log_probs, attn = self._decode_and_generate(
                decoder_input,
                memory_bank,
                batch,
                data,
                memory_lengths=memory_lengths,
                src_map=src_map,
                step=step,
                batch_offset=torch.arange(batch_size, dtype=torch.long)
            )

            if step < min_length:
                log_probs[:, end_token] = -1e20

            if self.forbid_unk:
                log_probs[:, unk_token] = -1e20

            # Note that what this code calls log_probs are actually logits.
            topk_ids, topk_scores = self.sample_with_temperature(
                    log_probs, sampling_temp, keep_topk)

            # Append last prediction.
            seq_so_far = torch.cat([seq_so_far, topk_ids.view(-1, 1)], -1)
            if return_attention:
                current_attn = attn
                if alive_attn is None:
                    alive_attn = current_attn
                else:
                    alive_attn = torch.cat([alive_attn, current_attn], 0)

        predictions = seq_so_far.view(-1, 1, seq_so_far.size(-1))
        attention = (
            alive_attn.view(
                alive_attn.size(0), -1, 1, alive_attn.size(-1))
            if alive_attn is not None else None)

        for i in range(topk_scores.size(0)):
            # Store finished hypotheses for this batch. Unlike in beam search,
            # there will only ever be 1 hypothesis per example.
            score = topk_scores[i, 0]
            pred = predictions[i, 0, 1:]  # Ignore start_token.
            # changed by wchen for HRE option
            if not isinstance(memory_lengths, tuple):
                m_len = memory_lengths[i]
                attn = attention[:, i, 0, :m_len] if attention is not None else []
            else:
                attn = attention[:, i, 0, :] if attention is not None else []

            results["scores"][i].append(score)
            results["predictions"][i].append(pred)
            results["attention"][i].append(attn)

        return results

    def translate_batch(self, batch, data, attn_debug, fast=False):
        """
        Translate a batch of sentences.

        Mostly a wrapper around :obj:`Beam`.

        Args:
           batch (:obj:`Batch`): a batch from a dataset object
           data (:obj:`Dataset`): the dataset object
           fast (bool): enables fast beam search (may not support all features)

        Todo:
           Shouldn't need the original dataset.
        """
        with torch.no_grad():
            if self.beam_size == 1:
                return self._translate_random_sampling(
                    batch,
                    data,
                    self.max_length,
                    min_length=self.min_length,
                    sampling_temp=self.random_sampling_temp,
                    keep_topk=self.sample_from_topk,
                    return_attention=attn_debug or self.replace_unk)
            if fast:
                return self._fast_translate_batch(
                    batch,
                    data,
                    self.max_length,
                    min_length=self.min_length,
                    n_best=self.n_best,
                    return_attention=attn_debug or self.replace_unk)
            else:
                return self._translate_batch(batch, data)

    def _run_encoder(self, batch, data_type):
        src = inputters.make_features(batch, 'src', data_type)
        src_lengths = None
        if data_type == 'text':
            # change by wchen. Add HRE option
            if len(batch.src) == 2:
                _, src_lengths = batch.src
            else:
                _, sent_nums, sent_lens = batch.src
                src_lengths = (sent_nums, sent_lens)
        elif data_type == 'audio':
            src_lengths = batch.src_lengths

        # add by wchen, add sent_position for SeqHRE encoder
        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            enc_states, memory_bank, src_lengths = self.model.encoder(
                src, src_lengths, sent_position_tuple=sent_position_tuple)
        elif hasattr(batch, "title"):
            title = inputters.make_features(batch, 'title', data_type)
            _, title_lengths = batch.title
            enc_states, memory_bank, src_lengths = self.model.encoder(
                (src, title), (src_lengths, title_lengths))
        else:
            enc_states, memory_bank, src_lengths = self.model.encoder(
                src, src_lengths)
        if src_lengths is None:
            assert not isinstance(memory_bank, tuple), \
                'Ensemble decoding only supported for text data'
            src_lengths = torch.Tensor(batch.batch_size) \
                               .type_as(memory_bank) \
                               .long() \
                               .fill_(memory_bank.size(0))
        return src, enc_states, memory_bank, src_lengths

    def _decode_and_generate(
        self,
        decoder_in,
        memory_bank,
        batch,
        data,
        memory_lengths,
        src_map=None,
        step=None,
        batch_offset=None
    ):

        tgt_field = self.fields["tgt"][0][1]
        unk_idx = tgt_field.vocab.stoi[tgt_field.unk_token]
        if self.copy_attn:
            # Turn any copied words into UNKs.
            decoder_in = decoder_in.masked_fill(
                decoder_in.gt(len(tgt_field.vocab) - 1), unk_idx
            )

        # Decoder forward, takes [tgt_len, batch, nfeats] as input
        # and [src_len, batch, hidden] as memory_bank
        # in case of inference tgt_len = 1, batch = beam times batch_size
        # in case of Gold Scoring tgt_len = actual length, batch = 1 batch

        # add by wchen, add sent_position for SeqHRE encoder
        # get src_sent_position

        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            # get src_word_sent_ids
            src_word_sent_ids = None
            if hasattr(batch, "src_word_sent_ids"):
                src_word_sent_ids = batch.src_word_sent_ids

            dec_out, dec_attn = self.model.decoder(
                decoder_in, memory_bank, memory_lengths=memory_lengths, step=step,
                sent_position_tuple=sent_position_tuple, src_word_sent_ids=src_word_sent_ids)
        else:
            dec_out, dec_attn = self.model.decoder(
                decoder_in, memory_bank, memory_lengths=memory_lengths, step=step, test=True)

        # Generator forward.
        if not self.copy_attn:
            attn = dec_attn["std"]
            log_probs = self.model.generator(dec_out.squeeze(0))
            # returns [(batch_size x beam_size) , vocab ] when 1 step
            # or [ tgt_len, batch_size, vocab ] when full sentence
        else:
            attn = dec_attn["copy"]
            scores = self.model.generator(dec_out.view(-1, dec_out.size(2)),
                                          attn.view(-1, attn.size(2)),
                                          src_map)
            # here we have scores [tgt_lenxbatch, vocab] or [beamxbatch, vocab]
            if batch_offset is None:
                scores = scores.view(batch.batch_size, -1, scores.size(-1))
            else:
                scores = scores.view(-1, self.beam_size, scores.size(-1))
            scores = data.collapse_copy_scores(
                scores,
                batch,
                tgt_field.vocab,
                data.src_vocabs,
                batch_dim=0,
                batch_offset=batch_offset
            )
            scores = scores.view(decoder_in.size(0), -1, scores.size(-1))
            log_probs = scores.squeeze(0).log()
            # returns [(batch_size x beam_size) , vocab ] when 1 step
            # or [ tgt_len, batch_size, vocab ] when full sentence
        return log_probs, attn

    def _fast_translate_batch(
        self,
        batch,
        data,
        max_length,
        min_length=0,
        n_best=1,
        return_attention=False
    ):
        # TODO: support these blacklisted features.
        assert not self.dump_beam
        assert not self.use_filter_pred
        assert self.block_ngram_repeat == 0
        assert self.global_scorer.beta == 0

        beam_size = self.beam_size
        batch_size = batch.batch_size
        tgt_field = self.fields['tgt'][0][1]
        vocab = tgt_field.vocab
        start_token = vocab.stoi[tgt_field.init_token]
        end_token = vocab.stoi[tgt_field.eos_token]

        # Encoder forward.
        src, enc_states, memory_bank, src_lengths = self._run_encoder(
            batch, data.data_type)
        self.model.decoder.init_state(src, memory_bank, enc_states)

        use_src_map = data.data_type == 'text' and self.copy_attn

        results = {}
        results["predictions"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["scores"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["attention"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["batch"] = batch
        if "tgt" in batch.__dict__:
            results["gold_score"] = self._score_target(
                batch,
                memory_bank,
                src_lengths,
                data,
                batch.src_map if use_src_map else None
            )
            self.model.decoder.init_state(src, memory_bank, enc_states)
        else:
            results["gold_score"] = [0] * batch_size

        # Tile states and memory beam_size times.
        self.model.decoder.map_state(
            lambda state, dim: tile(state, beam_size, dim=dim))
        if isinstance(memory_bank, tuple):
            memory_bank = tuple(tile(x, beam_size, dim=1) for x in memory_bank)
            mb_device = memory_bank[0].device
        else:
            memory_bank = tile(memory_bank, beam_size, dim=1)
            mb_device = memory_bank.device

        memory_lengths = tile(src_lengths, beam_size)
        src_map = (tile(batch.src_map, beam_size, dim=1)
                   if use_src_map else None)

        top_beam_finished = torch.zeros([batch_size], dtype=torch.uint8)
        batch_offset = torch.arange(batch_size, dtype=torch.long)
        beam_offset = torch.arange(
            0, batch_size * beam_size, step=beam_size, dtype=torch.long,
            device=mb_device)
        alive_seq = torch.full(
            [batch_size * beam_size, 1], start_token, dtype=torch.long,
            device=mb_device)
        alive_attn = None

        # Give full probability to the first beam on the first step.
        topk_log_probs = torch.tensor(
            [0.0] + [float("-inf")] * (beam_size - 1), device=mb_device
        ).repeat(batch_size)

        # Structure that holds finished hypotheses.
        hypotheses = [[] for _ in range(batch_size)]  # noqa: F812

        for step in range(max_length):
            decoder_input = alive_seq[:, -1].view(1, -1, 1)

            log_probs, attn = self._decode_and_generate(
                decoder_input,
                memory_bank,
                batch,
                data,
                memory_lengths=memory_lengths,
                src_map=src_map,
                step=step,
                batch_offset=batch_offset
            )

            vocab_size = log_probs.size(-1)

            if step < min_length:
                log_probs[:, end_token] = -1e20

            # Multiply probs by the beam probability.
            log_probs += topk_log_probs.view(-1).unsqueeze(1)

            alpha = self.global_scorer.alpha
            length_penalty = ((5.0 + (step + 1)) / 6.0) ** alpha

            # Flatten probs into a list of possibilities.
            curr_scores = log_probs / length_penalty
            curr_scores = curr_scores.reshape(-1, beam_size * vocab_size)
            topk_scores, topk_ids = curr_scores.topk(beam_size, dim=-1)

            # Recover log probs.
            topk_log_probs = topk_scores * length_penalty

            # Resolve beam origin and true word ids.
            topk_beam_index = topk_ids.div(vocab_size)
            topk_ids = topk_ids.fmod(vocab_size)

            # Map beam_index to batch_index in the flat representation.
            batch_index = (
                    topk_beam_index
                    + beam_offset[:topk_beam_index.size(0)].unsqueeze(1))
            select_indices = batch_index.view(-1)

            # Append last prediction.
            alive_seq = torch.cat(
                [alive_seq.index_select(0, select_indices),
                 topk_ids.view(-1, 1)], -1)
            if return_attention:
                current_attn = attn.index_select(1, select_indices)
                if alive_attn is None:
                    alive_attn = current_attn
                else:
                    alive_attn = alive_attn.index_select(1, select_indices)
                    alive_attn = torch.cat([alive_attn, current_attn], 0)

            is_finished = topk_ids.eq(end_token)
            if step + 1 == max_length:
                is_finished.fill_(1)

            # Save finished hypotheses.
            if is_finished.any():
                # Penalize beams that finished.
                topk_log_probs.masked_fill_(is_finished, -1e10)
                is_finished = is_finished.to('cpu')
                top_beam_finished |= is_finished[:, 0].eq(1)
                predictions = alive_seq.view(-1, beam_size, alive_seq.size(-1))
                attention = (
                    alive_attn.view(
                        alive_attn.size(0), -1, beam_size, alive_attn.size(-1))
                    if alive_attn is not None else None)
                non_finished_batch = []
                for i in range(is_finished.size(0)):
                    b = batch_offset[i]
                    finished_hyp = is_finished[i].nonzero().view(-1)
                    # Store finished hypotheses for this batch.
                    for j in finished_hyp:
                        hypotheses[b].append((
                            topk_scores[i, j],
                            predictions[i, j, 1:],  # Ignore start_token.
                            attention[:, i, j, :memory_lengths[i]]
                            if attention is not None else None))
                    # End condition is the top beam finished and we can return
                    # n_best hypotheses.
                    if top_beam_finished[i] and len(hypotheses[b]) >= n_best:
                        best_hyp = sorted(
                            hypotheses[b], key=lambda x: x[0], reverse=True)
                        for n, (score, pred, attn) in enumerate(best_hyp):
                            if n >= n_best:
                                break
                            results["scores"][b].append(score)
                            results["predictions"][b].append(pred)
                            results["attention"][b].append(
                                attn if attn is not None else [])
                    else:
                        non_finished_batch.append(i)
                non_finished = torch.tensor(non_finished_batch)
                # If all sentences are translated, no need to go further.
                if len(non_finished) == 0:
                    break
                # Remove finished batches for the next step.
                top_beam_finished = top_beam_finished.index_select(
                    0, non_finished)
                batch_offset = batch_offset.index_select(0, non_finished)
                non_finished = non_finished.to(topk_ids.device)
                topk_log_probs = topk_log_probs.index_select(0, non_finished)
                batch_index = batch_index.index_select(0, non_finished)
                select_indices = batch_index.view(-1)
                alive_seq = predictions.index_select(0, non_finished) \
                    .view(-1, alive_seq.size(-1))
                if alive_attn is not None:
                    alive_attn = attention.index_select(1, non_finished) \
                        .view(alive_attn.size(0),
                              -1, alive_attn.size(-1))

            # Reorder states.
            if isinstance(memory_bank, tuple):
                memory_bank = tuple(x.index_select(1, select_indices)
                                    for x in memory_bank)
            else:
                memory_bank = memory_bank.index_select(1, select_indices)

            memory_lengths = memory_lengths.index_select(0, select_indices)
            self.model.decoder.map_state(
                lambda state, dim: state.index_select(dim, select_indices))
            if src_map is not None:
                src_map = src_map.index_select(1, select_indices)

        return results

    def _translate_batch(self, batch, data):
        # (0) Prep each of the components of the search.
        # And helper method for reducing verbosity.
        beam_size = self.beam_size
        batch_size = batch.batch_size
        data_type = data.data_type
        tgt_field = self.fields['tgt'][0][1]
        vocab = tgt_field.vocab

        # Define a set of tokens to exclude from ngram-blocking
        exclusion_tokens = {vocab.stoi[t] for t in self.ignore_when_blocking}

        pad = vocab.stoi[tgt_field.pad_token]
        eos = vocab.stoi[tgt_field.eos_token]
        bos = vocab.stoi[tgt_field.init_token]
        beam = [onmt.translate.Beam(beam_size, n_best=self.n_best,
                                    cuda=self.cuda,
                                    global_scorer=self.global_scorer,
                                    pad=pad, eos=eos, bos=bos,
                                    min_length=self.min_length,
                                    stepwise_penalty=self.stepwise_penalty,
                                    block_ngram_repeat=self.block_ngram_repeat,
                                    exclusion_tokens=exclusion_tokens)
                for __ in range(batch_size)]

        # (1) Run the encoder on the src.
        src, enc_states, memory_bank, src_lengths = self._run_encoder(
            batch, data_type)
        self.model.decoder.init_state(src, memory_bank, enc_states)

        results = {}
        results["predictions"] = []
        results["scores"] = []
        results["attention"] = []
        results["batch"] = batch
        if "tgt" in batch.__dict__:
            results["gold_score"] = self._score_target(
                batch, memory_bank, src_lengths, data, batch.src_map
                if data_type == 'text' and self.copy_attn else None)
            self.model.decoder.init_state(src, memory_bank, enc_states)
        else:
            results["gold_score"] = [0] * batch_size

        # (2) Repeat src objects `beam_size` times.
        # We use now  batch_size x beam_size (same as fast mode)
        src_map = (tile(batch.src_map, beam_size, dim=1)
                   if data.data_type == 'text' and self.copy_attn else None)
        self.model.decoder.map_state(
            lambda state, dim: tile(state, beam_size, dim=dim))

        if isinstance(memory_bank, tuple):
            memory_bank = tuple(tile(x, beam_size, dim=1) for x in memory_bank)
        else:
            memory_bank = tile(memory_bank, beam_size, dim=1)
        memory_lengths = tile(src_lengths, beam_size)

        # (3) run the decoder to generate sentences, using beam search.
        for i in range(self.max_length):
            if all((b.done() for b in beam)):
                break

            # (a) Construct batch x beam_size nxt words.
            # Get all the pending current beam words and arrange for forward.

            inp = torch.stack([b.get_current_state() for b in beam])
            inp = inp.view(1, -1, 1)

            # (b) Decode and forward
            out, beam_attn = self._decode_and_generate(
                inp, memory_bank, batch, data, memory_lengths=memory_lengths,
                src_map=src_map, step=i
            )
            out = out.view(batch_size, beam_size, -1)
            beam_attn = beam_attn.view(batch_size, beam_size, -1)

            # (c) Advance each beam.
            select_indices_array = []
            # Loop over the batch_size number of beam
            for j, b in enumerate(beam):
                b.advance(out[j, :],
                          beam_attn.data[j, :, :memory_lengths[j]])
                select_indices_array.append(
                    b.get_current_origin() + j * beam_size)
            select_indices = torch.cat(select_indices_array)

            self.model.decoder.map_state(
                lambda state, dim: state.index_select(dim, select_indices))

        # (4) Extract sentences from beam.
        for b in beam:
            scores, ks = b.sort_finished(minimum=self.n_best)
            hyps, attn = [], []
            for i, (times, k) in enumerate(ks[:self.n_best]):
                hyp, att = b.get_hyp(times, k)
                hyps.append(hyp)
                attn.append(att)
            results["predictions"].append(hyps)
            results["scores"].append(scores)
            results["attention"].append(attn)

        return results

    def _score_target(self, batch, memory_bank, src_lengths, data, src_map):
        tgt_in = inputters.make_features(batch, 'tgt')[:-1]

        log_probs, attn = self._decode_and_generate(
            tgt_in, memory_bank, batch, data,
            memory_lengths=src_lengths, src_map=src_map)
        tgt_field = self.fields["tgt"][0][1]
        tgt_pad = tgt_field.vocab.stoi[tgt_field.pad_token]

        log_probs[:, :, tgt_pad] = 0
        gold = batch.tgt[1:].unsqueeze(2)
        gold_scores = log_probs.gather(2, gold)
        gold_scores = gold_scores.sum(dim=0).view(-1)

        return gold_scores

    def _report_score(self, name, score_total, words_total):
        if words_total == 0:
            msg = "%s No words predicted" % (name,)
        else:
            msg = ("%s AVG SCORE: %.4f, %s PPL: %.4f" % (
                name, score_total / words_total,
                name, math.exp(-score_total / words_total)))
        return msg

    def _report_bleu(self, tgt_path):
        import subprocess
        base_dir = os.path.abspath(__file__ + "/../../..")
        # Rollback pointer to the beginning.
        self.out_file.seek(0)
        print()

        res = subprocess.check_output(
            "perl %s/tools/multi-bleu.perl %s" % (base_dir, tgt_path),
            stdin=self.out_file, shell=True
        ).decode("utf-8")

        msg = ">> " + res.strip()
        return msg

    def _report_rouge(self, tgt_path):
        import subprocess
        path = os.path.split(os.path.realpath(__file__))[0]
        msg = subprocess.check_output(
            "python %s/tools/test_rouge.py -r %s -c STDIN" % (path, tgt_path),
            shell=True, stdin=self.out_file
        ).decode("utf-8").strip()
        return msg


class HRTranslator(object):
    """
    Uses a model to translate a batch of sentences.


    Args:
       model (:obj:`onmt.modules.HREDModel`):
          Hierarchical NMT model to use for translation
       fields (dict of Fields): data fields, the tgt field must be an object of NestedField
       beam_size (int): size of beam to use, currently only beam_size=1 (greedy search) is supported
       n_best (int): number of translations produced
       max_kp_length (int): maximum length of each keyphrase output to produce
       max_kp_num (int): maximum number of keyphrase output to produce
       copy_attn (bool): use copy attention during translation
       cuda (bool): use cuda
       logger(logging.Logger): logger.
    """

    def __init__(
        self,
        model,
        fields,
        opt,
        model_opt,
        out_file=None,
        logger=None
    ):

        self.model = model
        self.fields = fields
        self.gpu = opt.gpu
        self.cuda = opt.gpu > -1

        assert opt.n_best == 1
        self.n_best = opt.n_best
        self.max_kp_length = opt.max_kp_length
        self.max_kp_num = opt.max_kp_num
        self.min_kp_length = opt.min_kp_length
        self.min_kp_num = opt.min_kp_num

        if opt.beam_size != 1 and opt.random_sampling_topk != 1:
            raise ValueError('Can either do beam search OR random sampling.')

        # greedy search: beam_size = 1 and opt.random_sampling_topk = 1
        assert opt.beam_size == 1
        assert opt.random_sampling_topk == 1
        self.beam_size = opt.beam_size
        self.sample_from_topk = opt.random_sampling_topk
        self.random_sampling_temp = opt.random_sampling_temp

        # self.min_length = opt.min_length
        self.stepwise_penalty = opt.stepwise_penalty
        self.dump_beam = opt.dump_beam
        # TODO: to see whether block_ngram_repeat is useful
        self.block_ngram_repeat = opt.block_ngram_repeat
        self.ignore_when_blocking = set(opt.ignore_when_blocking)

        self.replace_unk = opt.replace_unk
        self.data_type = opt.data_type
        self.verbose = opt.verbose
        self.report_bleu = opt.report_bleu
        self.report_rouge = opt.report_rouge
        self.fast = opt.fast

        self.copy_attn = model_opt.copy_attn

        # add by wchen for logging
        self.translate_report_num = opt.translate_report_num

        self.out_file = out_file
        self.logger = logger

        self.use_filter_pred = False

        self.forbid_unk = opt.forbid_unk
        self.first_valid_word_exclusive_search = opt.first_valid_word_exclusive_search
        self.exclusive_window_size = opt.exclusive_window_size

        # for debugging
        self.beam_trace = self.dump_beam != ""
        self.beam_accum = None
        if self.beam_trace:
            self.beam_accum = {
                "predicted_ids": [],
                "beam_parent_ids": [],
                "scores": [],
                "log_probs": []}

    def translate(
        self,
        src,
        src_title=None,
        tgt=None,
        batch_size=None,
        attn_debug=False,
        src_dir=None
    ):
        """
        Translate content of `src_data_iter` (if not None) or `src_path`
        and get gold scores if one of `tgt_data_iter` or `tgt_path` is set.

        Note: batch_size must not be None
        Note: one of ('src_path', 'src_data_iter') must not be None

        Args:
            src_path (str): filepath of source data
            src_title_path (str): filepath of title of source data
            tgt_path (str): filepath of target data or None
            batch_size (int): size of examples per mini-batch
            attn_debug (bool): enables the attention logging
            src_dir (str): Not used for the 'text' type

        Returns:
            (`list`, `list`)

            * all_scores is a list of `batch_size` lists of `n_best` scores
            * all_predictions is a list of `batch_size` lists
                of `n_best` predictions
        """
        assert src is not None

        if batch_size is None:
            raise ValueError("batch_size must be set")

        data = inputters.build_dataset(
            self.fields,
            self.data_type,
            src=src,
            title=src_title,
            tgt=tgt,
            use_filter_pred=self.use_filter_pred,
        )

        cur_device = "cuda" if self.cuda else "cpu"

        data_iter = inputters.OrderedIterator(
            dataset=data,
            device=cur_device,
            batch_size=batch_size,
            train=False,
            sort=False,
            sort_within_batch=True,
            shuffle=False
        )

        builder = onmt.translate.HRTranslationBuilder(
            data, self.fields, self.n_best, self.replace_unk, tgt,
            eokp_token=EOKP_TOKEN, sep_token=KEY_SEPERATOR, p_end_token=P_END, a_end_token=A_END)

        # Statistics
        counter = count(1)
        pred_score_total, pred_words_total = 0, 0
        gold_score_total, gold_words_total = 0, 0

        all_scores = []
        all_predictions = []

        finished_num = 0
        for batch in data_iter:
            batch_data = self.translate_batch(
                batch, data, attn_debug, fast=self.fast
            )
            translations = builder.from_batch(batch_data)

            for trans in translations:
                # all_scores += [trans.pred_scores[:self.n_best]]
                # pred_score_total += trans.pred_scores[0]
                pred_words_total += len(trans.pred_sents)
                if tgt is not None:
                    gold_score_total += trans.gold_score
                    gold_words_total += len(trans.gold_sent) + 1

                greedy_pred = " ".join(trans.pred_sents)
                all_predictions += [greedy_pred]
                # self.out_file.write('\n'.join(n_best_preds) + '\n')
                # change by wchen
                self.out_file.write(greedy_pred + '\n')
                self.out_file.flush()

                finished_num += 1
                if finished_num % self.translate_report_num == 0:
                    self.logger.info("{} test samples finished.".format(finished_num))
                # TODO: support self.verbose
                assert not self.verbose
                if self.verbose:
                    sent_number = next(counter)
                    output = trans.log(sent_number)
                    if self.logger:
                        self.logger.info(output)
                    else:
                        os.write(1, output.encode('utf-8'))
                # TODO: support attn_debug
                assert not attn_debug
                if attn_debug:
                    preds = trans.pred_sents[0]
                    preds.append('</s>')
                    attns = trans.attns[0].tolist()
                    if self.data_type == 'text':
                        srcs = trans.src_raw
                    else:
                        srcs = [str(item) for item in range(len(attns[0]))]
                    header_format = "{:>10.10} " + "{:>10.7} " * len(srcs)
                    row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    output = header_format.format("", *srcs) + '\n'
                    for word, row in zip(preds, attns):
                        max_index = row.index(max(row))
                        row_format = row_format.replace(
                            "{:>10.7f} ", "{:*>10.7f} ", max_index + 1)
                        row_format = row_format.replace(
                            "{:*>10.7f} ", "{:>10.7f} ", max_index)
                        output += row_format.format(word, *row) + '\n'
                        row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    os.write(1, output.encode('utf-8'))

        # TODO: support self.dump_beam
        assert not self.dump_beam
        if self.dump_beam:
            import json
            json.dump(self.translator.beam_accum,
                      codecs.open(self.dump_beam, 'w', 'utf-8'))
        return all_scores, all_predictions

    def _translate_greedy_search(
        self,
        batch,
        data,
        max_kp_length,
        max_kp_num,
        min_kp_length=1,
        min_kp_num=1,
        keep_topk=1,
        return_attention=False
    ):
        """Greedy search for hierarchical decoding."""

        assert self.beam_size == 1
        assert keep_topk == 1

        # TODO: support these blacklisted features.
        assert self.block_ngram_repeat == 0

        batch_size = batch.batch_size
        tgt_field = self.fields["tgt"][0][1]
        vocab = tgt_field.vocab
        start_token = vocab.stoi[tgt_field.nesting_field.init_token]

        word_end_token = vocab.stoi[EOKP_TOKEN] if EOKP_TOKEN in vocab.stoi else None
        word_sep_token = vocab.stoi[KEY_SEPERATOR] if KEY_SEPERATOR in vocab.stoi else None
        p_end_token = vocab.stoi[P_END] if P_END in vocab.stoi else None
        a_end_token = vocab.stoi[A_END] if A_END in vocab.stoi else None

        sent_end_token = vocab.stoi[tgt_field.eos_token]
        pad_token = vocab.stoi[tgt_field.pad_token]
        unk_token = vocab.stoi[tgt_field.unk_token]


        # Encoder forward.
        src, enc_states, memory_banks, src_lengths = self._run_encoder(
            batch, data.data_type)
        # make the decoder input format consistent
        if not isinstance(memory_banks, tuple):
            # ensure the memory banks are batch first
            memory_banks = (memory_banks.transpose(0, 1),)
            src_lengths = (src_lengths,)

        self.model.decoder.init_state(None, None, enc_states)

        use_src_map = data.data_type == 'text' and self.copy_attn

        results = {}
        results["predictions"] = []
        results["scores"] = []
        results["attention"] = []
        results["batch"] = batch
        # if "tgt" in batch.__dict__:
        #     # TODO: revise the code in _score_target function
        #     results["gold_score"] = self._score_target(
        #         batch,
        #         memory_banks,
        #         src_lengths,
        #         data,
        #         batch.src_map if use_src_map else None
        #     )
        #     self.model.decoder.init_state(None, None, enc_states)
        # else:
        results["gold_score"] = [0] * batch_size

        memory_lengths = src_lengths
        src_map = batch.src_map if use_src_map else None

        if isinstance(memory_banks, tuple):
            mb_device = memory_banks[0].device
        else:
            mb_device = memory_banks.device

        # hr_seq_so_far contains chosen tokens;
        # on each sentence decoding step, dim 1 grows by one.
        # on each word decoding step, dim 2 grows by one
        sent_seq_so_far = None
        sent_alive_attn = None
        sent_dec_finished = torch.zeros(batch_size, dtype=torch.uint8).cuda()
        filled_value_for_finished = torch.full([batch_size], 0, device=mb_device)
        for sent_step in range(max_kp_num):
            word_seq_so_far = torch.full(
                [batch_size, 1, 1], start_token, dtype=torch.long, device=mb_device)
            # use the pad token for the sent_dec_finished samples
            word_seq_so_far.masked_fill_(sent_dec_finished.view(batch_size, 1, 1), pad_token)

            word_alive_attn = None
            word_dec_finished = torch.zeros(batch_size, dtype=torch.uint8).cuda()
            for word_step in range(max_kp_length):
                word_decoder_input = word_seq_so_far[:, 0, -1].view(-1, 1, 1, 1)

                # check whether the last step is already finished
                # 1. when the output of the last step is sep token or p_end_token or a_end_token
                if word_sep_token is not None:
                    word_dec_finished = word_dec_finished | (word_decoder_input == word_sep_token).view(-1)
                if p_end_token is not None:
                    word_dec_finished = word_dec_finished | (word_decoder_input == p_end_token).view(-1)
                if a_end_token is not None:
                    word_dec_finished = word_dec_finished | (word_decoder_input == a_end_token).view(-1)
                # 2. when the output of the last step is eok token
                if word_end_token is not None:
                    word_dec_finished = word_dec_finished | (word_decoder_input == word_end_token).view(-1)
                # 3. when the sentence level decoding is finished
                word_dec_finished = word_dec_finished | sent_dec_finished

                # use the state of the last step as the finished word decoding state
                # condition 1
                last_step_cond1 = word_step == (max_kp_length - 1)
                # Or condition 2
                last_step_cond2 = word_dec_finished.sum().item() == batch_size
                # log_probs: [batch_size, vocab]
                log_probs, attn = self._decode_and_generate(
                    word_decoder_input,
                    memory_banks,
                    batch,
                    data,
                    memory_lengths=memory_lengths,
                    src_map=src_map,
                    batch_offset=torch.arange(batch_size, dtype=torch.long),
                    last_step=last_step_cond1 or last_step_cond2
                )

                if word_step < min_kp_length:
                    for token in [word_sep_token, p_end_token, a_end_token, word_end_token]:
                        if token is not None:
                            log_probs[:, token] = -1e20
                if sent_step < min_kp_num or word_step >= 1:
                    # 1. when not meet the minimum kp number
                    # 2. avoid the <eos> token appeared at the second or later position.
                    log_probs[:, sent_end_token] = -1e20
                if self.forbid_unk:
                    log_probs[:, unk_token] = -1e20

                if self.first_valid_word_exclusive_search and self.exclusive_window_size != 0 and sent_step >= 1:
                    # TODO: if condition is bad code, need to be more elegant
                    if (p_end_token is None and word_step == 1) or (p_end_token is not None and word_step == 0):
                        history_step = min(self.exclusive_window_size, sent_step) if self.exclusive_window_size != -1 else sent_step
                        # [b_size, min(win_size, sent_step)]
                        first_valid_word_history = sent_seq_so_far[:, (sent_step - history_step):, word_step]
                        log_probs.scatter_(dim=1, index=first_valid_word_history, value=-1e20)

                # when finished, force to output pad token
                log_probs[:, pad_token] =\
                    torch.where(word_dec_finished.view(-1), filled_value_for_finished, log_probs[:, pad_token])

                # keep_topk=1 is also equivalent to argmax.
                # [batch_size, 1]
                topk_scores, topk_ids = log_probs.topk(1, dim=-1)

                # Append last prediction.
                # [batch_size, 1, word_step + 2]
                word_seq_so_far = torch.cat([word_seq_so_far, topk_ids.view(-1, 1, 1)], -1)

                current_attn = attn.view(1, 1, batch_size, -1)
                if word_alive_attn is None:
                    # [1, 1, batch, s_num * s_len]
                    word_alive_attn = current_attn
                else:
                    # [1, word_step+1, batch, s_num * s_len]
                    word_alive_attn = torch.cat([word_alive_attn, current_attn], 1)

                # check whether current word decoding is finished
                if word_dec_finished.sum().item() == batch_size:
                    break

                # check whether current sent level decoding for this batch is finished
                sent_dec_finished = sent_dec_finished | (topk_ids.view(-1) == sent_end_token)

            # ignore the start token
            word_seq_so_far = word_seq_so_far[:, :, 1:]
            orig_kp_len = word_seq_so_far.size(-1)

            # complement word_seq_so_far with max_kp_length
            extra_tensors = torch.full([batch_size, 1, max_kp_length - orig_kp_len], pad_token,
                                       dtype=word_seq_so_far.dtype, device=mb_device)
            # [batch_size, 1, max_kp_length]
            word_seq_so_far = torch.cat([word_seq_so_far, extra_tensors], dim=-1)

            # complement word_alive_attn with max_kp_length
            extra_tensors = torch.full([1, max_kp_length - orig_kp_len, batch_size, word_alive_attn.size(-1)],
                                       0.0, dtype=word_alive_attn.dtype, device=mb_device)
            # [1, max_kp_length, batch, s_num * s_len]
            word_alive_attn = torch.cat([word_alive_attn, extra_tensors], dim=1)

            # concatenate all the decoded keyphrases
            if sent_seq_so_far is None:
                # [batch_size, 1, max_kp_length]
                sent_seq_so_far = word_seq_so_far
                # [1, max_kp_length, batch, s_num * s_len]
                sent_alive_attn = word_alive_attn
            else:
                # [batch_size, sent_step + 1, max_kp_length]
                sent_seq_so_far = torch.cat([sent_seq_so_far, word_seq_so_far], dim=1)
                # [sent_step + 1, max_kp_length, batch, s_num * s_len]
                sent_alive_attn = torch.cat([sent_alive_attn, word_alive_attn], dim=0)

            if sent_dec_finished.sum().item() == batch_size:
                break

        # [batch_size, tgt_s_num, max_kp_length]
        predictions = sent_seq_so_far
        # [tgt_s_num, max_kp_length, batch, s_num * s_len]
        attention = sent_alive_attn if sent_alive_attn is not None else None

        for i in range(topk_scores.size(0)):
            # Store finished hypotheses for this batch. Unlike in beam search,
            # there will only ever be 1 hypothesis per example.
            # [1]
            score = topk_scores[i, 0]
            # [tgt_s_num, max_kp_length]
            pred = predictions[i]
            # [tgt_s_num, max_kp_length, s_num * s_len]
            attn = attention[:, :, i, :]

            results["scores"].append(score)
            results["predictions"].append(pred)
            results["attention"].append(attn)

        return results

    def translate_batch(self, batch, data, attn_debug, fast=False):
        """
        Translate a batch of sentences.

        Mostly a wrapper around :obj:`Beam`.

        Args:
           batch (:obj:`Batch`): a batch from a dataset object
           data (:obj:`Dataset`): the dataset object
           fast (bool): enables fast beam search (may not support all features), not supported yet

        Todo:
           Shouldn't need the original dataset.
        """
        with torch.no_grad():
            # Currently, only the greedy search is supported
            assert self.beam_size == 1
            assert self.sample_from_topk == 1
            return self._translate_greedy_search(
                batch,
                data,
                max_kp_length=self.max_kp_length,
                max_kp_num=self.max_kp_num,
                min_kp_length=self.min_kp_length,
                min_kp_num=self.min_kp_num,
                keep_topk=self.sample_from_topk,
                return_attention=attn_debug or self.replace_unk)

    def _run_encoder(self, batch, data_type):
        src = inputters.make_features(batch, 'src', data_type)
        assert data_type == 'text'
        if len(batch.src) == 3:
            _, sent_nums, sent_lens = batch.src
            src_lengths = (sent_nums, sent_lens)
        else:
            _, src_lengths = batch.src

        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            enc_states, memory_banks, src_lengths =\
                self.model.encoder(src, src_lengths, sent_position_tuple=sent_position_tuple)
        else:
            enc_states, memory_banks, src_lengths = self.model.encoder(src, src_lengths)

        assert src_lengths is not None
        return src, enc_states, memory_banks, src_lengths

    def _decode_and_generate(self, word_decoder_in, memory_banks, batch, data, memory_lengths,
                             src_map=None, batch_offset=None, last_step=False):
        """
        Decoding and generating step for inference
        :param word_decoder_in (`LongTensor`): sequences of last predicted tokens
                 `[batch x tgt_s_num x tgt_s_len x nfeats]`
        :param memory_banks (`tuple`): the memory banks from encoder
                `(word_memory_bank,)` from a seq encoder with size `([batch x src_len x hidden],)`
                `(sent_memory_bank, word_memory_bank)` from a hr encoder with size
                `([batch x s_num x hidden], [batch x s_num x s_len x hidden])`.
        :param batch (Batch): the current batch
        :param data (TextDataset):
        :param memory_lengths (`tuple`): the source lengths
                `(src_lengths,)` for a sequence encoded memory bank with size `([batch],)`
                `(sent_nums, sent_lens)` for hr encoded memory banks with size `([batch], [batch x s_num])`.
        :param src_map (`FloatTensor`):
                A sparse indicator matrix mapping each source word to
                its index in the "extended" vocab containing.
                `[src_len, batch, extra_words]` size for seq encoder.
                `[s_num * s_len, batch, src_vocab_size]` size for hr encoder.
        :param batch_offset:
        :param last_step ('bool'): Only used for translation.
                Whether current step is the last step of word level decoding.
        :return:
        """
        tgt_field = self.fields["tgt"][0][1]
        unk_idx = tgt_field.vocab.stoi[tgt_field.unk_token]
        if self.copy_attn:
            # Turn any copied words into UNKs.
            word_decoder_in = word_decoder_in.masked_fill(
                word_decoder_in.gt(len(tgt_field.vocab) - 1), unk_idx
            )

        # Decoder forward, takes [batch, tgt_s_num, tgt_s_len, nfeats] as input
        # in case of inference tgt_s_num = 1, tgt_s_len = 1,
        assert isinstance(memory_banks, tuple)
        # assert isinstance(memory_lengths, tuple)

        # dec_out: [tgt_s_num * tgt_s_len, batch, h_size]
        # dec_attn['word_std']: [tgt_s_num, tgt_s_len, batch, s_num, s_len]
        # dec_attn['copy']: [tgt_s_num * tgt_s_len, batch, s_num * s_len]
        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            # get src_word_sent_ids
            src_word_sent_ids = None
            if hasattr(batch, "src_word_sent_ids"):
                src_word_sent_ids = batch.src_word_sent_ids

            dec_out, dec_attn = self.model.decoder(
                word_decoder_in, memory_banks,
                memory_lengths=memory_lengths,
                sent_position_tuple=sent_position_tuple,
                src_word_sent_ids=src_word_sent_ids,
                last_step=last_step, testing=True)
        else:
            dec_out, dec_attn = self.model.decoder(
                word_decoder_in, memory_banks,
                memory_lengths=memory_lengths,
                last_step=last_step, testing=True)

        # Generator forward.
        if not self.copy_attn:
            # [tgt_s_num, tgt_s_len, batch, s_num, s_len]
            attn = dec_attn["word_std"]
            log_probs = self.model.generator(dec_out.squeeze(0))
            # returns [batch_size , vocab ] when 1 step
        else:
            attn = dec_attn["copy"]
            # here we have scores [tgt_s_num x tgt_s_len x batch, extended_vocab]
            scores = self.model.generator(dec_out.view(-1, dec_out.size(2)),
                                          attn.view(-1, attn.size(2)),
                                          src_map)
            # [tgt_s_num x tgt_s_len, batch, extended_vocab]
            scores = scores.view(-1, batch.batch_size, scores.size(-1))

            scores = data.collapse_copy_scores(
                scores,
                batch,
                tgt_field.vocab,
                data.src_vocabs,
                batch_dim=1,
                batch_offset=batch_offset
            )
            # [tgt_s_num x tgt_s_len, batch_size, vocab]
            scores = scores.view(-1, batch.batch_size, scores.size(-1))
            log_probs = scores.squeeze(0).log()
            # returns [batch_size, vocab ] when 1 step
            # or [ tgt_len, batch_size, vocab ] when full sentence
        return log_probs, attn

    def _score_target(self, batch, memory_bank, src_lengths, data, src_map):
        tgt_in = inputters.make_features(batch, 'tgt')[:-1]

        log_probs, attn = self._decode_and_generate(
            tgt_in, memory_bank, batch, data,
            memory_lengths=src_lengths, src_map=src_map)
        tgt_field = self.fields["tgt"][0][1]
        tgt_pad = tgt_field.vocab.stoi[tgt_field.pad_token]

        log_probs[:, :, tgt_pad] = 0
        gold = batch.tgt[1:].unsqueeze(2)
        gold_scores = log_probs.gather(2, gold)
        gold_scores = gold_scores.sum(dim=0).view(-1)

        return gold_scores

    def _report_score(self, name, score_total, words_total):
        if words_total == 0:
            msg = "%s No words predicted" % (name,)
        else:
            msg = ("%s AVG SCORE: %.4f, %s PPL: %.4f" % (
                name, score_total / words_total,
                name, math.exp(-score_total / words_total)))
        return msg

    def _report_bleu(self, tgt_path):
        import subprocess
        base_dir = os.path.abspath(__file__ + "/../../..")
        # Rollback pointer to the beginning.
        self.out_file.seek(0)
        print()

        res = subprocess.check_output(
            "perl %s/tools/multi-bleu.perl %s" % (base_dir, tgt_path),
            stdin=self.out_file, shell=True
        ).decode("utf-8")

        msg = ">> " + res.strip()
        return msg

    def _report_rouge(self, tgt_path):
        import subprocess
        path = os.path.split(os.path.realpath(__file__))[0]
        msg = subprocess.check_output(
            "python %s/tools/test_rouge.py -r %s -c STDIN" % (path, tgt_path),
            shell=True, stdin=self.out_file
        ).decode("utf-8").strip()
        return msg


class SeqTranslator(object):
    """
    Uses a model to translate a batch of sentences.


    Args:
       model (:obj:`onmt.modules.NMTModel`):
          NMT model to use for translation
       fields (dict of Fields): data fields
       beam_size (int): size of beam to use
       n_best (int): number of translations produced
       max_length (int): maximum length output to produce
       global_scores (:obj:`GlobalScorer`):
         object to rescore final translations
       copy_attn (bool): use copy attention during translation
       cuda (bool): use cuda
       beam_trace (bool): trace beam search for debugging
       logger(logging.Logger): logger.
    """

    def __init__(
        self,
        model,
        fields,
        opt,
        model_opt,
        global_scorer=None,
        out_file=None,
        report_score=True,
        logger=None
    ):

        self.model = model
        self.fields = fields
        self.gpu = opt.gpu
        self.cuda = opt.gpu > -1

        self.n_best = opt.n_best
        self.max_length = opt.max_length

        if opt.beam_size != 1 and opt.random_sampling_topk != 1:
            raise ValueError('Can either do beam search OR random sampling.')

        self.beam_size = opt.beam_size
        self.random_sampling_temp = opt.random_sampling_temp
        self.sample_from_topk = opt.random_sampling_topk

        self.min_length = opt.min_length
        self.stepwise_penalty = opt.stepwise_penalty
        self.dump_beam = opt.dump_beam
        self.block_ngram_repeat = opt.block_ngram_repeat
        self.ignore_when_blocking = set(opt.ignore_when_blocking)
        self.sample_rate = opt.sample_rate
        self.window_size = opt.window_size
        self.window_stride = opt.window_stride
        self.window = opt.window
        self.image_channel_size = opt.image_channel_size
        self.replace_unk = opt.replace_unk
        self.data_type = opt.data_type
        self.verbose = opt.verbose
        self.report_bleu = opt.report_bleu
        self.report_rouge = opt.report_rouge
        self.fast = opt.fast

        self.copy_attn = model_opt.copy_attn

        self.global_scorer = global_scorer
        self.out_file = out_file
        self.report_score = report_score
        self.logger = logger

        self.use_filter_pred = False

        # add by wchen
        self.forbid_unk = opt.forbid_unk
        # add by wchen for exclusive search
        self.first_valid_word_exclusive_search = opt.first_valid_word_exclusive_search
        self.exclusive_window_size = opt.exclusive_window_size

        # for debugging
        self.beam_trace = self.dump_beam != ""
        self.beam_accum = None
        if self.beam_trace:
            self.beam_accum = {
                "predicted_ids": [],
                "beam_parent_ids": [],
                "scores": [],
                "log_probs": []}

    def translate(
        self,
        src,
        src_title=None,
        tgt=None,
        src_dir=None,
        batch_size=None,
        attn_debug=False
    ):
        """
        Translate content of `src_data_iter` (if not None) or `src_path`
        and get gold scores if one of `tgt_data_iter` or `tgt_path` is set.

        Note: batch_size must not be None
        Note: one of ('src_path', 'src_data_iter') must not be None

        Args:
            src_path (str): filepath of source data
            tgt_path (str): filepath of target data or None
            src_dir (str): source directory path
                (used for Audio and Image datasets)
            batch_size (int): size of examples per mini-batch
            attn_debug (bool): enables the attention logging

        Returns:
            (`list`, `list`)

            * all_scores is a list of `batch_size` lists of `n_best` scores
            * all_predictions is a list of `batch_size` lists
                of `n_best` predictions
        """
        assert src is not None

        if batch_size is None:
            raise ValueError("batch_size must be set")

        data = inputters.build_dataset(
            self.fields,
            self.data_type,
            src=src,
            title=src_title,
            tgt=tgt,
            src_dir=src_dir,
            sample_rate=self.sample_rate,
            window_size=self.window_size,
            window_stride=self.window_stride,
            window=self.window,
            use_filter_pred=self.use_filter_pred,
            image_channel_size=self.image_channel_size,
        )

        cur_device = "cuda" if self.cuda else "cpu"

        data_iter = inputters.OrderedIterator(
            dataset=data,
            device=cur_device,
            batch_size=batch_size,
            train=False,
            sort=False,
            sort_within_batch=True,
            shuffle=False
        )

        builder = onmt.translate.TranslationBuilder(
            data, self.fields, self.n_best, self.replace_unk, tgt
        )

        # Statistics
        counter = count(1)
        pred_score_total, pred_words_total = 0, 0
        gold_score_total, gold_words_total = 0, 0

        all_scores = []
        all_predictions = []

        for batch in data_iter:
            batch_data = self.translate_batch(
                batch, data, attn_debug, fast=self.fast
            )
            translations = builder.from_batch(batch_data)

            for trans in translations:
                all_scores += [trans.pred_scores[:self.n_best]]
                pred_score_total += trans.pred_scores[0]
                pred_words_total += len(trans.pred_sents[0])
                if tgt is not None:
                    gold_score_total += trans.gold_score
                    gold_words_total += len(trans.gold_sent) + 1

                n_best_preds = [" ".join(pred)
                                for pred in trans.pred_sents[:self.n_best]]
                all_predictions += [n_best_preds]
                # self.out_file.write('\n'.join(n_best_preds) + '\n')
                # change by wchen
                self.out_file.write(' {} '.format(KEY_SEPERATOR).join(n_best_preds) + '\n')
                self.out_file.flush()

                if self.verbose:
                    sent_number = next(counter)
                    output = trans.log(sent_number)
                    if self.logger:
                        self.logger.info(output)
                    else:
                        os.write(1, output.encode('utf-8'))

                if attn_debug:
                    preds = trans.pred_sents[0]
                    preds.append('</s>')
                    attns = trans.attns[0].tolist()
                    if self.data_type == 'text':
                        srcs = trans.src_raw
                    else:
                        srcs = [str(item) for item in range(len(attns[0]))]
                    header_format = "{:>10.10} " + "{:>10.7} " * len(srcs)
                    row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    output = header_format.format("", *srcs) + '\n'
                    for word, row in zip(preds, attns):
                        max_index = row.index(max(row))
                        row_format = row_format.replace(
                            "{:>10.7f} ", "{:*>10.7f} ", max_index + 1)
                        row_format = row_format.replace(
                            "{:*>10.7f} ", "{:>10.7f} ", max_index)
                        output += row_format.format(word, *row) + '\n'
                        row_format = "{:>10.10} " + "{:>10.7f} " * len(srcs)
                    os.write(1, output.encode('utf-8'))

        if self.report_score:
            msg = self._report_score('PRED', pred_score_total,
                                     pred_words_total)
            if self.logger:
                self.logger.info(msg)
            else:
                print(msg)
            if tgt is not None:
                msg = self._report_score('GOLD', gold_score_total,
                                         gold_words_total)
                if self.logger:
                    self.logger.info(msg)
                else:
                    print(msg)
                if self.report_bleu:
                    msg = self._report_bleu(tgt)
                    if self.logger:
                        self.logger.info(msg)
                    else:
                        print(msg)
                if self.report_rouge:
                    msg = self._report_rouge(tgt)
                    if self.logger:
                        self.logger.info(msg)
                    else:
                        print(msg)

        if self.dump_beam:
            import json
            json.dump(self.translator.beam_accum,
                      codecs.open(self.dump_beam, 'w', 'utf-8'))
        return all_scores, all_predictions

    def _translate_exclusive_greedy(
        self,
        batch,
        data,
        max_length,
        min_length=0,
        sampling_temp=1.0,
        keep_topk=-1,
        return_attention=False
    ):
        """Alternative to beam search. Do random sampling at each step."""

        assert self.beam_size == 1
        assert self.block_ngram_repeat == 0
        assert sampling_temp == 0.0 and keep_topk == 1

        batch_size = batch.batch_size

        # changed by wchen, the above is the original
        tgt_field = self.fields["tgt"][0][1]
        vocab = tgt_field.vocab
        start_token = vocab.stoi[tgt_field.init_token]
        end_token = vocab.stoi[tgt_field.eos_token]
        unk_token = vocab.stoi[tgt_field.unk_token]
        p_start_token = vocab.stoi[P_START]
        a_start_token = vocab.stoi[A_START]

        # Encoder forward.
        src, enc_states, memory_bank, src_lengths = self._run_encoder(
            batch, data.data_type)
        self.model.decoder.init_state(src, memory_bank, enc_states)

        use_src_map = data.data_type == 'text' and self.copy_attn

        results = {}
        results["predictions"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["scores"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["attention"] = [[] for _ in range(batch_size)]  # noqa: F812
        results["batch"] = batch
        results["gold_score"] = [0] * batch_size

        memory_lengths = src_lengths
        src_map = batch.src_map if use_src_map else None

        if isinstance(memory_bank, tuple):
            mb_device = memory_bank[0].device
        else:
            mb_device = memory_bank.device

        # seq_so_far contains chosen tokens; on each step, dim 1 grows by one.
        seq_so_far = torch.full(
            [batch_size, 1], start_token, dtype=torch.long, device=mb_device)
        alive_attn = None

        first_valid_word_history = [[] for _ in range(batch_size)]
        first_w_flag = torch.zeros([batch_size], device=mb_device) == 1
        for step in range(max_length):
            decoder_input = seq_so_far[:, -1].view(1, -1, 1)

            log_probs, attn = self._decode_and_generate(
                decoder_input,
                memory_bank,
                batch,
                data,
                memory_lengths=memory_lengths,
                src_map=src_map,
                step=step,
                batch_offset=torch.arange(batch_size, dtype=torch.long)
            )

            if step < min_length:
                log_probs[:, end_token] = -1e20

            if self.forbid_unk:
                log_probs[:, unk_token] = -1e20

            # for exclusive search, forbidding generating the same first word with the previous one
            if self.first_valid_word_exclusive_search and self.exclusive_window_size != 0:
                for b_idx in range(batch_size):
                    if first_w_flag[b_idx]:
                        history_num = len(first_valid_word_history[b_idx])
                        if history_num != 0:
                            ex_step = min(self.exclusive_window_size, history_num) if self.exclusive_window_size != -1 else history_num
                            for first_w_idx in first_valid_word_history[b_idx][history_num - ex_step:]:
                                log_probs[b_idx, first_w_idx] = -1e20

            # Note that what this code calls log_probs are actually logits.
            topk_scores, topk_ids = log_probs.topk(keep_topk, dim=-1)

            # for exclusive search
            if self.first_valid_word_exclusive_search and self.exclusive_window_size != 0:
                # store the firt valid words into first_valid_word_history
                for b_idx in range(batch_size):
                    if first_w_flag[b_idx]:
                        first_valid_word_history[b_idx].append(topk_ids[b_idx])
                # update first_w_flag to indicate whether the next word is a valid first word
                p_start_flag = topk_ids == p_start_token
                a_start_flag = topk_ids == a_start_token
                first_w_flag = p_start_flag | a_start_flag

            # Append last prediction.
            seq_so_far = torch.cat([seq_so_far, topk_ids.view(-1, 1)], -1)
            if return_attention:
                current_attn = attn
                if alive_attn is None:
                    alive_attn = current_attn
                else:
                    alive_attn = torch.cat([alive_attn, current_attn], 0)

        predictions = seq_so_far.view(-1, 1, seq_so_far.size(-1))
        attention = (
            alive_attn.view(
                alive_attn.size(0), -1, 1, alive_attn.size(-1))
            if alive_attn is not None else None)

        for i in range(topk_scores.size(0)):
            # Store finished hypotheses for this batch. Unlike in beam search,
            # there will only ever be 1 hypothesis per example.
            score = topk_scores[i, 0]
            pred = predictions[i, 0, 1:]  # Ignore start_token.
            # changed by wchen for HRE option
            if not isinstance(memory_lengths, tuple):
                m_len = memory_lengths[i]
                attn = attention[:, i, 0, :m_len] if attention is not None else []
            else:
                attn = attention[:, i, 0, :] if attention is not None else []

            results["scores"][i].append(score)
            results["predictions"][i].append(pred)
            results["attention"][i].append(attn)

        return results

    def translate_batch(self, batch, data, attn_debug, fast=False):
        """
        Translate a batch of sentences.

        Mostly a wrapper around :obj:`Beam`.

        Args:
           batch (:obj:`Batch`): a batch from a dataset object
           data (:obj:`Dataset`): the dataset object
           fast (bool): enables fast beam search (may not support all features)

        Todo:
           Shouldn't need the original dataset.
        """
        with torch.no_grad():
            assert self.beam_size == 1
            assert not fast
            return self._translate_exclusive_greedy(
                batch,
                data,
                self.max_length,
                min_length=self.min_length,
                sampling_temp=self.random_sampling_temp,
                keep_topk=self.sample_from_topk,
                return_attention=attn_debug or self.replace_unk)

    def _run_encoder(self, batch, data_type):
        src = inputters.make_features(batch, 'src', data_type)
        src_lengths = None
        if data_type == 'text':
            # change by wchen. Add HRE option
            if len(batch.src) == 2:
                _, src_lengths = batch.src
            else:
                _, sent_nums, sent_lens = batch.src
                src_lengths = (sent_nums, sent_lens)
        elif data_type == 'audio':
            src_lengths = batch.src_lengths

        # add by wchen, add sent_position for SeqHRE encoder
        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            enc_states, memory_bank, src_lengths = self.model.encoder(
                src, src_lengths, sent_position_tuple=sent_position_tuple)
        elif hasattr(batch, "title"):
            title = inputters.make_features(batch, 'title', data_type)
            _, title_lengths = batch.title
            enc_states, memory_bank, src_lengths = self.model.encoder(
                (src, title), (src_lengths, title_lengths))
        else:
            enc_states, memory_bank, src_lengths = self.model.encoder(
                src, src_lengths)
        if src_lengths is None:
            assert not isinstance(memory_bank, tuple), \
                'Ensemble decoding only supported for text data'
            src_lengths = torch.Tensor(batch.batch_size) \
                               .type_as(memory_bank) \
                               .long() \
                               .fill_(memory_bank.size(0))
        return src, enc_states, memory_bank, src_lengths

    def _decode_and_generate(
        self,
        decoder_in,
        memory_bank,
        batch,
        data,
        memory_lengths,
        src_map=None,
        step=None,
        batch_offset=None
    ):

        tgt_field = self.fields["tgt"][0][1]
        unk_idx = tgt_field.vocab.stoi[tgt_field.unk_token]
        if self.copy_attn:
            # Turn any copied words into UNKs.
            decoder_in = decoder_in.masked_fill(
                decoder_in.gt(len(tgt_field.vocab) - 1), unk_idx
            )

        # Decoder forward, takes [tgt_len, batch, nfeats] as input
        # and [src_len, batch, hidden] as memory_bank
        # in case of inference tgt_len = 1, batch = beam times batch_size
        # in case of Gold Scoring tgt_len = actual length, batch = 1 batch

        # add by wchen, add sent_position for SeqHRE encoder
        # get src_sent_position

        if hasattr(batch, "src_sent_position"):
            sent_position_tuple = batch.src_sent_position
            # get src_word_sent_ids
            src_word_sent_ids = None
            if hasattr(batch, "src_word_sent_ids"):
                src_word_sent_ids = batch.src_word_sent_ids

            dec_out, dec_attn = self.model.decoder(
                decoder_in, memory_bank, memory_lengths=memory_lengths, step=step,
                sent_position_tuple=sent_position_tuple, src_word_sent_ids=src_word_sent_ids)
        else:
            dec_out, dec_attn = self.model.decoder(
                decoder_in, memory_bank, memory_lengths=memory_lengths, step=step, test=True)

        # Generator forward.
        if not self.copy_attn:
            attn = dec_attn["std"]
            log_probs = self.model.generator(dec_out.squeeze(0))
            # returns [(batch_size x beam_size) , vocab ] when 1 step
            # or [ tgt_len, batch_size, vocab ] when full sentence
        else:
            attn = dec_attn["copy"]
            scores = self.model.generator(dec_out.view(-1, dec_out.size(2)),
                                          attn.view(-1, attn.size(2)),
                                          src_map)
            # here we have scores [tgt_lenxbatch, vocab] or [beamxbatch, vocab]
            if batch_offset is None:
                scores = scores.view(batch.batch_size, -1, scores.size(-1))
            else:
                scores = scores.view(-1, self.beam_size, scores.size(-1))
            scores = data.collapse_copy_scores(
                scores,
                batch,
                tgt_field.vocab,
                data.src_vocabs,
                batch_dim=0,
                batch_offset=batch_offset
            )
            scores = scores.view(decoder_in.size(0), -1, scores.size(-1))
            log_probs = scores.squeeze(0).log()
            # returns [(batch_size x beam_size) , vocab ] when 1 step
            # or [ tgt_len, batch_size, vocab ] when full sentence
        return log_probs, attn

    def _score_target(self, batch, memory_bank, src_lengths, data, src_map):
        tgt_in = inputters.make_features(batch, 'tgt')[:-1]

        log_probs, attn = self._decode_and_generate(
            tgt_in, memory_bank, batch, data,
            memory_lengths=src_lengths, src_map=src_map)
        tgt_field = self.fields["tgt"][0][1]
        tgt_pad = tgt_field.vocab.stoi[tgt_field.pad_token]

        log_probs[:, :, tgt_pad] = 0
        gold = batch.tgt[1:].unsqueeze(2)
        gold_scores = log_probs.gather(2, gold)
        gold_scores = gold_scores.sum(dim=0).view(-1)

        return gold_scores

    def _report_score(self, name, score_total, words_total):
        if words_total == 0:
            msg = "%s No words predicted" % (name,)
        else:
            msg = ("%s AVG SCORE: %.4f, %s PPL: %.4f" % (
                name, score_total / words_total,
                name, math.exp(-score_total / words_total)))
        return msg

    def _report_bleu(self, tgt_path):
        import subprocess
        base_dir = os.path.abspath(__file__ + "/../../..")
        # Rollback pointer to the beginning.
        self.out_file.seek(0)
        print()

        res = subprocess.check_output(
            "perl %s/tools/multi-bleu.perl %s" % (base_dir, tgt_path),
            stdin=self.out_file, shell=True
        ).decode("utf-8")

        msg = ">> " + res.strip()
        return msg

    def _report_rouge(self, tgt_path):
        import subprocess
        path = os.path.split(os.path.realpath(__file__))[0]
        msg = subprocess.check_output(
            "python %s/tools/test_rouge.py -r %s -c STDIN" % (path, tgt_path),
            shell=True, stdin=self.out_file
        ).decode("utf-8").strip()
        return msg
